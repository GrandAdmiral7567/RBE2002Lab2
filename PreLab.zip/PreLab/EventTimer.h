#include <Arduino.h>
#ifndef __EVENT_TIMER
#define __EVENT_TIEMR

//button class with state machine for debouncing
class EventTimer
{
private:



public:
	//create event timer
	EventTimer();

	//init and run check
	void Start(int interval);
	void CheckExpired(void);
	void Cancel(void);


};

#endif