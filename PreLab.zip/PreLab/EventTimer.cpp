#include "EventTimer.h"


EventTimer::EventTimer()
{
	unsigned long startTime;
	unsigned long stopTime;
	unsigned long currentTime;
	const unsigned long period = 1000;

}


void EventTimer::Start(int interval) { 
	stopTime = interval;
	Serial.begin(9600);  
	//start time
	startTime = millis(); 
}



void EventTimer::CheckExpired(void) {
	//check current time
	currentTime = millis(); 
	//have we hit our interval?
	if (currentTime - startTime >= stopTime)  
	{
		Cancel(void);
	}
}

void EventTimer::Cancel(void) {
	startTime = currentTime;
}

